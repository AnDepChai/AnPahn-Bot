const path = require('path');
const { ReactemojiChannels: cfgReactemojiChannels } = require(path.resolve(__dirname, '../config.json'));

module.exports = {
  name: "messageCreate",
  async execute(message) {
    if (!message) return;
    if (message.author.bot) return;

    const ReactemojiChannels = Array.isArray(cfgReactemojiChannels)
      ? cfgReactemojiChannels.map(id => id.toString())
      : (cfgReactemojiChannels ? [cfgReactemojiChannels.toString()] : []);

    if (!ReactemojiChannels.includes(message.channel.id)) return;

    if (message.attachments.size > 0) {
      try {
        await message.react("1239156742605242388"); // emoji :_pepe_yes:
        await message.react("1239156779309465611"); // emoji :_pepe_no:
      } catch (err) {
      }
    }
  },
};