const { EmbedBuilder, PermissionsBitField, ChannelType } = require('discord.js');
const path = require('path');
const { AutoBanChannelId } = require(path.resolve(__dirname, '../config.json'));

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (!message.guild) return;
    if (message.author.bot) return;
    if (message.webhookId) return;
    if (message.channel.id !== AutoBanChannelId) return;

    const guild = message.guild;
    const botMember = guild.members.me;
    if (!botMember) return;

    try {
      await message.delete().catch(() => {});

      if (!botMember.permissions.has(PermissionsBitField.Flags.BanMembers)) return;

      const targetMember = await guild.members.fetch(message.author.id).catch(() => null);
      if (!targetMember) return;

      if (
        targetMember.id === guild.ownerId ||
        targetMember.permissions.has(PermissionsBitField.Flags.Administrator) ||
        targetMember.roles.highest.position >= botMember.roles.highest.position
      ) {
        return;
      }

      if (targetMember.bannable === false) return;

      const dmEmbed = new EmbedBuilder()
        .setColor(0xFF66CC)
        .setAuthor({ name: guild.name, iconURL: guild.iconURL() })
        .setDescription(
          "<:despair:1303695882386145382> 𝙱ạ𝚗 𝚋ị **𝙱𝙰𝙽 𝚅Ĩ𝙽𝙷 𝚅𝙸Ễ𝙽**\n\n" +
          "- 𝙽ế𝚞 𝚗𝚐𝚑ĩ đâ𝚢 𝚕à 𝚗𝚑ầ𝚖 𝚕ẫ𝚗, 𝚑ã𝚢 𝚕𝚒ê𝚗 𝚑ệ <@958668688607838208> để đượ𝚌 𝚡𝚎𝚖 𝚡é𝚝 𝚕ạ𝚒."
        )
        .setFooter({ text: "𝙱𝙰𝙽𝙽𝙴𝙳 𝙱𝚈 𝙰𝚄𝚃𝙾 𝙱𝙰𝙽 ! 𝙰𝙽𝙿𝙰𝙷𝙽" })
        .setTimestamp();

      await message.author.send({ embeds: [dmEmbed] }).catch(() => {});

      if (botMember.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
        const channels = guild.channels.cache.filter(
          c => c.type === ChannelType.GuildText && c.viewable
        );

        const now = Date.now();
        const fourteenDays = 14 * 24 * 60 * 60 * 1000;

        for (const channel of channels.values()) {
          const perms = channel.permissionsFor(botMember);
          if (!perms?.has([PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.ManageMessages])) continue;

          const fetched = await channel.messages.fetch({ limit: 50 }).catch(() => null);
          if (!fetched) continue;

          const userMessages = fetched.filter(
            m => m.author.id === targetMember.id && (now - m.createdTimestamp) < fourteenDays
          );

          if (userMessages.size > 0) {
            await channel.bulkDelete(userMessages, true).catch(() => {});
          }

          await new Promise(r => setTimeout(r, 250));
        }
      }

      await guild.members.ban(targetMember.id, {
        reason: "𝚂𝚙𝚊𝚖/𝙱𝚘𝚝/𝙽𝚒𝚌𝚔 𝙶𝚒ả 𝙼ạ𝚘 | 𝙱𝙰𝙽𝙽𝙴𝙳 𝙱𝚈 𝙱𝙾𝚃 ! 𝙰𝙽𝙿𝙰𝙷𝙽"
      });

    } catch (err) {
      console.error('[AUTO BAN ERROR]', err);
    }
  }
};