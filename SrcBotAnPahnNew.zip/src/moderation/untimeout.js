const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  MessageFlags
} = require("discord.js");

const config = require("../config.json");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unmute")
    .setDescription("ɢỡ ᴍᴜᴛᴇ ᴄʜᴏ ɴɢườɪ ᴅùɴɢ")
    .addUserOption(o =>
      o.setName("ai_đó")
        .setDescription("ɴɢườɪ ᴄầɴ ɢỡ ᴍᴜᴛᴇ")
        .setRequired(true)),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const user = interaction.options.getUser("ai_đó");

    if (user.bot) {
      return interaction.reply({
        content: "⚠️ ᴋʜôɴɢ ᴄầɴ ɢỡ ᴍᴜᴛᴇ ʙᴏᴛ.",
        flags: MessageFlags.Ephemeral
      });
    }

    if (user.id === interaction.user.id) {
      return interaction.reply({
        content: "⚠️ ʙạɴ ᴋʜôɴɢ ᴄầɴ ɢỡ ᴍᴜᴛᴇ ᴄʜíɴʜ ᴍìɴʜ.",
        flags: MessageFlags.Ephemeral
      });
    }

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({
        content: "⚠️ ᴋʜôɴɢ ᴛìᴍ ᴛʜấʏ ɴɢườɪ ᴅùɴɢ.",
        flags: MessageFlags.Ephemeral
      });
    }

    if (!member.isCommunicationDisabled()) {
      return interaction.reply({
        content: "⚠️ ɴɢườɪ ɴàʏ ʜɪệɴ ᴋʜôɴɢ ʙị ᴍᴜᴛᴇ.",
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({
        content: "⛔ ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **MODERATE MEMBERS**.",
        flags: MessageFlags.Ephemeral
      });
    }

    if (member.roles.highest.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: "🛡 ᴋʜôɴɢ ᴛʜể ɢỡ ᴍᴜᴛᴇ ɴɢườɪ ᴄó ᴠᴀɪ ᴛʀò ᴄᴀᴏ ʜơɴ ʙᴏᴛ.",
        flags: MessageFlags.Ephemeral
      });
    }

    try {
      await member.timeout(null);
    } catch (err) {
      console.error(err);
      return interaction.reply({
        content: "❎ ᴋʜôɴɢ ᴛʜể ɢỡ ᴍᴜᴛᴇ. ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.",
        flags: MessageFlags.Ephemeral
      });
    }

    const embed = new EmbedBuilder()
      .setColor(0x66FF99)
      .setDescription(`👤 ${user} đã đượᴄ ɢỡ ᴍᴜᴛᴇ.`)
      .setFooter({ text: "© ᴄᴏᴅᴇ ʙʏ ᴀɴ ᴘᴀʜɴ 🐧" })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed],
      flags: MessageFlags.Ephemeral
    });
  }
};