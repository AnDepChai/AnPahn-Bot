const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  MessageFlags
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('ᴄảɴʜ ᴄáᴏ ɴɢườɪ ᴅùɴɢ.')
    .addUserOption(o =>
      o.setName('ai_đó')
        .setDescription('ɴɢườɪ ʙị ᴄảɴʜ ᴄáᴏ')
        .setRequired(true))
    .addStringOption(o =>
      o.setName('lý_do')
        .setDescription('ʟý ᴅᴏ ᴄảɴʜ ᴄáᴏ')),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const user = interaction.options.getUser('ai_đó');
    const reason = interaction.options.getString('lý_do') ?? 'ᴋʜôɴɢ ʟý ᴅᴏ';

    if (user.bot) {
      return interaction.reply({
        content: '❌ ᴋʜôɴɢ ᴛʜể ᴄảɴʜ ᴄáᴏ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (user.id === interaction.user.id) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴛʜể ᴛự ᴄảɴʜ ᴄáᴏ ᴄʜíɴʜ ᴍìɴʜ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({
        content: '⚠️ ɴɢườɪ ɴàʏ ᴋʜôɴɢ ᴄòɴ ở ᴛʀᴏɴɢ sᴇʀᴠᴇʀ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (member.roles.highest.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: '🛡 ᴋʜôɴɢ ᴛʜể ᴄảɴʜ ᴄáᴏ ɴɢườɪ ᴄó ᴠᴀɪ ᴛʀò ᴄᴀᴏ ʜơɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const warnEmbed = new EmbedBuilder()
      .setColor('#ffcc00')
      .setTitle('⚠️ ᴄảɴʜ ᴄáᴏ')
      .setDescription(
        `👤 **ɴɢườɪ ʙị ᴄảɴʜ ᴄáᴏ:** ${user}\n` +
        `📝 **ʟý ᴅᴏ:** ${reason}\n\n` +
        `📌 ʜãʏ ᴄʜấᴘ ʜàɴʜ ɴộɪ ǫᴜʏ sᴇʀᴠᴇʀ.`
      )
      .setFooter({ text: '© ᴄᴏᴅᴇ ʙʏ ᴀɴ ᴘᴀʜɴ 🐧' })
      .setTimestamp();

    await interaction.reply({
      embeds: [warnEmbed],
      flags: MessageFlags.Ephemeral
    });

    await user.send({ embeds: [warnEmbed] }).catch(() => {});
  }
};