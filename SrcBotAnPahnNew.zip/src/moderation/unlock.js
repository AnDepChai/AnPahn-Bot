const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  ChannelType,
  MessageFlags
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('🔓 ᴍở ᴋʜᴏá ᴄʜᴀᴛ ᴋêɴʜ')
    .addChannelOption(option =>
      option
        .setName('ᴋêɴʜ')
        .setDescription('ᴄʜọɴ ᴋêɴʜ ᴄầɴ ᴍở ᴋʜᴏá (ʙỏ ᴛʀốɴɢ = ᴋêɴʜ ʜɪệɴ ᴛạɪ)')
        .addChannelTypes(ChannelType.GuildText)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const channel =
      interaction.options.getChannel('ᴋêɴʜ') || interaction.channel;

    if (!channel || channel.type !== ChannelType.GuildText) {
      return interaction.reply({
        content: '❌ ʟệɴʜ ɴàʏ ᴄʜỉ sử ᴅụɴɢ ᴛʀᴏɴɢ ᴋêɴʜ ᴠăɴ ʙảɴ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({
        content: '🛡 ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **MANAGE CHANNELS**.',
        flags: MessageFlags.Ephemeral
      });
    }

    const everyoneOverwrite = channel.permissionOverwrites.cache.get(
      interaction.guild.roles.everyone.id
    );

    if (!everyoneOverwrite?.deny.has(PermissionFlagsBits.SendMessages)) {
      return interaction.reply({
        content: '🔓 ᴋêɴʜ ɴàʏ ʜɪệɴ ᴋʜôɴɢ ʙị ᴋʜᴏá.',
        flags: MessageFlags.Ephemeral
      });
    }

    try {
      await channel.permissionOverwrites.edit(
        interaction.guild.roles.everyone,
        { SendMessages: null }
      );
    } catch (err) {
      console.error(err);
      return interaction.reply({
        content: '❎ ᴋʜôɴɢ ᴛʜể ᴍở ᴋʜᴏá ᴋêɴʜ. ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const embed = new EmbedBuilder()
      .setColor('#00ff99')
      .setTitle('🔓 ᴍở ᴋʜᴏá ᴄʜᴀᴛ')
      .setDescription(
        `📢 **ᴋêɴʜ:** ${channel}\n` +
        `🔓 **ᴛʀạɴɢ ᴛʜáɪ:** ᴍở`
      )
      .setFooter({ text: `ʙởɪ ${interaction.user.tag}` })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed],
      flags: MessageFlags.Ephemeral
    });
  }
};