const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
  MessageFlags,
  ComponentType
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clean')
    .setDescription('xóa ᴛɪɴ ɴʜắɴ ʜàɴɢ ʟᴏᴀ̣ᴛ')
    .addIntegerOption(option =>
      option.setName('số_ʟượɴɢ')
        .setDescription('số ʟượɴɢ ᴛɪɴ ɴʜắɴ ᴄầɴ xóa (1-100)')
        .setMinValue(1)
        .setMaxValue(100)
        .setRequired(true))
    .addUserOption(option =>
      option.setName('ʟọᴄ_ᴛʜᴇᴏ_ɴɢườɪ_ᴅùɴɢ')
        .setDescription('ᴄʜỉ xóa ᴛɪɴ ɴʜắɴ ᴄủᴀ ɴɢườɪ ᴅùɴɢ'))
    .addRoleOption(option =>
      option.setName('ʟọᴄ_ᴛʜᴇᴏ_ᴠᴀɪ_ᴛʀò')
        .setDescription('ᴄʜỉ xóa ᴛɪɴ ɴʜắɴ ᴄủᴀ ᴠᴀɪ ᴛʀò'))
    .addBooleanOption(option =>
      option.setName('ᴄʜỉ_xóa_ʙᴏᴛ')
        .setDescription('ᴄʜỉ xóa ᴛɪɴ ɴʜắɴ ᴄủᴀ ʙᴏᴛ')),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember) return;

    if (!botMember.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return interaction.reply({
        content: '🛡 ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ xóa ᴛɪɴ ɴʜắɴ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const amount = interaction.options.getInteger('số_ʟượɴɢ');
    const user = interaction.options.getUser('ʟọᴄ_ᴛʜᴇᴏ_ɴɢườɪ_ᴅùɴɢ');
    const role = interaction.options.getRole('ʟọᴄ_ᴛʜᴇᴏ_ᴠᴀɪ_ᴛʀò');
    const onlyBot = interaction.options.getBoolean('ᴄʜỉ_xóa_ʙᴏᴛ');
    const channel = interaction.channel;

    const fetched = await channel.messages.fetch({ limit: 100 });

    const filtered = fetched.filter(msg => {
      if (user && msg.author.id !== user.id) return false;
      if (role && !msg.member?.roles.cache.has(role.id)) return false;
      if (onlyBot === true && !msg.author.bot) return false;

      // Discord không cho xóa tin > 14 ngày
      if (Date.now() - msg.createdTimestamp > 1_209_600_000) return false;

      return true;
    });

    const previewMessages = filtered.first(amount);

    if (!previewMessages.length) {
      return interaction.reply({
        content: '⚠️ ᴋʜôɴɢ ᴄó ᴛɪɴ ɴʜắɴ ɴàᴏ để xóa.',
        flags: MessageFlags.Ephemeral
      });
    }

    const previewEmbed = new EmbedBuilder()
      .setColor('#ffcc00')
      .setTitle('⚠️ xáᴄ ɴʜậɴ xóa ᴛɪɴ ɴʜắɴ')
      .setDescription(
        `🗑 **số ᴛɪɴ sắᴘ xóa:** ${previewMessages.length}\n` +
        `📝 **ᴋêɴʜ:** ${channel}\n\n` +
        `👤 **ɴɢườɪ ᴅùɴɢ:** ${user ?? 'ᴛấᴛ ᴄả'}\n` +
        `🎭 **ᴠᴀɪ ᴛʀò:** ${role ?? 'ᴋʜôɴɢ'}\n` +
        `🤖 **ᴄʜỉ xóa ʙᴏᴛ:** ${onlyBot ? 'ᴄó' : 'ᴋʜôɴɢ'}`
      )
      .setFooter({ text: '© ᴄᴏᴅᴇ ʙʏ ᴀɴᴘᴀʜɴ 🐧' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_delete')
        .setLabel('Xáᴄ ɴʜậɴ')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('cancel_delete')
        .setLabel('ʜủʏ')
        .setStyle(ButtonStyle.Secondary)
    );

    const message = await interaction.reply({
      embeds: [previewEmbed],
      components: [row],
      flags: MessageFlags.Ephemeral,
      fetchReply: true
    });

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 30_000,
      max: 1
    });

    collector.on('collect', async i => {
      if (i.user.id !== interaction.user.id) {
        return i.reply({
          content: '❎ ʙạɴ ᴋʜôɴɢ ᴘʜảɪ ɴɢườɪ ɴʜấɴ ʟệɴʜ ɴàʏ.',
          flags: MessageFlags.Ephemeral
        });
      }

      if (i.customId === 'cancel_delete') {
        return i.update({
          content: '❎ ʜủʏ ᴠɪệᴄ xóa ᴛɪɴ ɴʜắɴ.',
          embeds: [],
          components: []
        });
      }

      try {
        await channel.bulkDelete(previewMessages, true);

        await i.update({
          embeds: [
            new EmbedBuilder()
              .setColor('#00ff99')
              .setDescription(`✅ xóa **${previewMessages.length}** ᴛɪɴ ɴʜắɴ.`)
          ],
          components: []
        });
      } catch (err) {
        console.error(err);
        await i.update({
          content: '❎ ʟỗɪ ᴋʜɪ xóa ᴛɪɴ ɴʜắɴ.',
          embeds: [],
          components: []
        });
      }
    });

    collector.on('end', async (_, reason) => {
      if (reason === 'time') {
        await message.edit({
          content: '⏰ ʜếᴛ ᴛʜờɪ ɢɪᴀɴ xáᴄ ɴʜậɴ.',
          embeds: [],
          components: []
        }).catch(() => {});
      }
    });
  }
};

/*
const {
  SlashCommandBuilder,
  MessageFlags,
  PermissionFlagsBits,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

const config = require('../config.json');

function buildConfirmContainer(data) {
  const { count, channel, user, role, onlyBot } = data;

  return new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# ⚠️ xáᴄ ɴʜậɴ xóa ᴛɪɴ ɴʜắɴ\n` +
        `🗑 **số ᴛɪɴ sắᴘ xóa:** ${count}\n` +
        `📝 **ᴋêɴʜ:** ${channel}\n\n` +
        `👤 **ɴɢườɪ ᴅùɴɢ:** ${user ?? 'ᴛấᴛ ᴄả'}\n` +
        `🎭 **ᴠᴀɪ ᴛʀò:** ${role ?? 'ᴋʜôɴɢ'}\n` +
        `🤖 **ᴄʜỉ xóa ʙᴏᴛ:** ${onlyBot ? 'ᴄó' : 'ᴋʜôɴɢ'}`
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        '© ᴄᴏᴅᴇ ʙʏ ᴀɴᴘᴀʜɴ 🐧'
      )
    );
}

function buildConfirmButtons(disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('clean:confirm')
      .setLabel('Xáᴄ ɴʜậɴ')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(disabled),

    new ButtonBuilder()
      .setCustomId('clean:cancel')
      .setLabel('ʜủʏ')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled)
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clean')
    .setDescription('xóa ᴛɪɴ ɴʜắɴ ʜàɴɢ ʟᴏᴀ̣ᴛ.')
    .addIntegerOption(o =>
      o.setName('số_lượng')
        .setDescription('số ʟượɴɢ ᴛɪɴ ɴʜắɴ ᴄầɴ xóa (1–100)')
        .setMinValue(1)
        .setMaxValue(100)
        .setRequired(true)
    )
    .addUserOption(o =>
      o.setName('lọc_theo_người_dùng')
        .setDescription('ᴄʜỉ xóa ᴛɪɴ ɴʜắɴ ᴄủᴀ ɴɢườɪ ᴅùɴɢ.')
    )
    .addRoleOption(o =>
      o.setName('lọc_theo_vai_trò')
        .setDescription('ᴄʜỉ xóa ᴛɪɴ ɴʜắɴ ᴄủᴀ ᴠᴀɪ ᴛʀò.')
    )
    .addBooleanOption(o =>
      o.setName('chỉ_xóa_bot')
        .setDescription('ᴄʜỉ xóa ᴛɪɴ ɴʜắɴ ᴄủᴀ ʙᴏᴛ.')
    ),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return interaction.reply({
        content: '🛡 ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ xóa ᴛɪɴ ɴʜắɴ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const amount = interaction.options.getInteger('số_lượng');
    const user = interaction.options.getUser('lọc_theo_người_dùng');
    const role = interaction.options.getRole('lọc_theo_vai_trò');
    const onlyBot = interaction.options.getBoolean('chỉ_xóa_bot');
    const channel = interaction.channel;

    const fetched = await channel.messages.fetch({ limit: 100 });

    const filtered = fetched.filter(msg => {
      if (user && msg.author.id !== user.id) return false;
      if (role && !msg.member?.roles.cache.has(role.id)) return false;
      if (onlyBot === true && !msg.author.bot) return false;
      if (Date.now() - msg.createdTimestamp > 1_209_600_000) return false;
      return true;
    });

    const messages = filtered.first(amount);

    if (!messages.length) {
      return interaction.reply({
        content: '⚠️ ᴋʜôɴɢ ᴄó ᴛɪɴ ɴʜắɴ ɴàᴏ để xóa.',
        flags: MessageFlags.Ephemeral
      });
    }

    interaction.client.cleanState ??= new Map();
    interaction.client.cleanState.set(interaction.id, {
      messages,
      channel
    });

    await interaction.reply({
      flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      components: [
        buildConfirmContainer({
          count: messages.length,
          channel,
          user,
          role,
          onlyBot
        }),
        buildConfirmButtons()
      ],
      allowedMentions: { parse: [] }
    });
  },

  async handleButton(interaction) {
    const state = interaction.client.cleanState?.get(
      interaction.message.interaction.id
    );
    if (!state) return interaction.deferUpdate();

    if (interaction.user.id !== interaction.message.interaction.user.id) {
      return interaction.reply({
        content: '❎ ʙạɴ ᴋʜôɴɢ ᴘʜảɪ ɴɢườɪ ɴʜấɴ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const { messages, channel } = state;

    if (interaction.customId === 'clean:cancel') {
      interaction.client.cleanState.delete(interaction.message.interaction.id);

      return interaction.update({
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        components: [
          new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent('❎ ʜủʏ ᴠɪệᴄ xóa ᴛɪɴ ɴʜắɴ.')
          )
        ]
      });
    }

    try {
      await channel.bulkDelete(messages, true);

      interaction.client.cleanState.delete(interaction.message.interaction.id);

      await interaction.update({
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        components: [
          new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `✅ xóa **${messages.length}** ᴛɪɴ ɴʜắɴ.`
            )
          )
        ]
      });
    } catch (err) {
      console.error(err);

      await interaction.update({
        content: '❎ ʟỗɪ ᴋʜɪ xóa ᴛɪɴ ɴʜắɴ.',
        components: []
      });
    }
  }
};
*/