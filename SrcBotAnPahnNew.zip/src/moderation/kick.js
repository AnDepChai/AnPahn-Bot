const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ComponentType,
  PermissionFlagsBits
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('ᴋɪᴄᴋ ɴɢườɪ ᴅùɴɢ ᴋʜỏɪ sᴇʀᴠᴇʀ.')
    .addUserOption(option =>
      option.setName('ai_đó')
        .setDescription('ɴɢườɪ ᴅùɴɢ ᴄầɴ ʙị ᴋɪᴄᴋ.')
        .setRequired(true)
    ),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const user = interaction.options.getUser('ai_đó');

    if (user.id === interaction.user.id) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴛʜể ᴋɪᴄᴋ ᴄʜíɴʜ ᴍìɴʜ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (user.id === interaction.guild.ownerId) {
      return interaction.reply({
        content: '⛔ ᴋʜôɴɢ ᴛʜể ᴋɪᴄᴋ ᴄʜủ sᴇʀᴠᴇʀ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({
        content: '⚠️ ɴɢườɪ ɴàʏ ᴋʜôɴɢ ᴄòɴ ᴛʀᴏɴɢ sᴇʀᴠᴇʀ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember) return;

    if (
      !botMember.permissions.has(PermissionFlagsBits.KickMembers) ||
      member.roles.highest.position >= botMember.roles.highest.position
    ) {
      return interaction.reply({
        content: '⛔ ʙᴏᴛ ᴋʜôɴɢ đủ ǫᴜʏềɴ ʜᴏặᴄ ᴠᴀɪ ᴛʀò ɴɢườɪ ɴàʏ ᴄᴀᴏ ʜơɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor('#ffcc00')
      .setTitle('⚠️ xáᴄ ɴʜậɴ ᴋɪᴄᴋ')
      .setDescription(
        `ʙạɴ ᴄó ᴄʜắᴄ ᴄʜắɴ ᴍᴜốɴ ᴋɪᴄᴋ:\n\n` +
        `👤 ɴɢườɪ ʙị ᴋɪᴄᴋ: ${member}`
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_kick')
        .setLabel('Xác nhận')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('cancel_kick')
        .setLabel('Huỷ')
        .setStyle(ButtonStyle.Secondary)
    );

    const message = await interaction.reply({
      embeds: [confirmEmbed],
      components: [row],
      flags: MessageFlags.Ephemeral,
      fetchReply: true
    });

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 30_000,
      max: 1
    });

    collector.on('collect', async i => {
      if (i.user.id !== interaction.user.id) {
        return i.reply({
          content: '❌ ʙạɴ ᴋʜôɴɢ đượᴄ ᴘʜéᴘ sử ᴅụɴɢ núᴛ ɴàʏ.',
          flags: MessageFlags.Ephemeral
        });
      }

      if (i.customId === 'cancel_kick') {
        return i.update({
          content: '❌ ʜuỷ ʜàɴʜ độɴɢ ᴋɪᴄᴋ.',
          embeds: [],
          components: []
        });
      }

      try {
        await member.kick(`Kicked by ${interaction.user.tag}`);

        await i.update({
          embeds: [
            new EmbedBuilder()
              .setColor('#ff9900')
              .setDescription(`✅ ᴋɪᴄᴋ **${member.user.tag}** ʀᴀ ᴋʜỏɪ sᴇʀᴠᴇʀ.`)
          ],
          components: []
        });
      } catch (err) {
        console.error(err);
        await i.update({
          content: '❌ ᴋʜôɴɢ ᴛʜể ᴋɪᴄᴋ. ʜãʏ ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
          embeds: [],
          components: []
        });
      }
    });

    collector.on('end', async (_, reason) => {
      if (reason === 'time') {
        await message.edit({
          content: '⌛ ʜếᴛ ᴛʜờɪ ɢɪᴀɴ xáᴄ ɴʜậɴ.',
          embeds: [],
          components: []
        }).catch(() => {});
      }
    });
  }
};

/*
const {
  SlashCommandBuilder,
  MessageFlags,
  PermissionFlagsBits,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

const config = require('../config.json');

function buildConfirmContainer(member) {
  return new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# ⚠️ xáᴄ ɴʜậɴ ᴋɪᴄᴋ\n\n` +
        `👤 **ɴɢườɪ ʙị ᴋɪᴄᴋ:** ${member}\n\n` +
        `❗ ʜàɴʜ độɴɢ ɴàʏ ᴋʜôɴɢ ᴛʜể ʜᴏàɴ ᴛáᴄ.`
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        '© ᴄᴏᴅᴇ ʙʏ ᴀɴᴘᴀʜɴ 🐧'
      )
    );
}

function buildConfirmButtons(disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('kick:confirm')
      .setLabel('Xáᴄ ɴʜậɴ')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(disabled),

    new ButtonBuilder()
      .setCustomId('kick:cancel')
      .setLabel('ʜủʏ')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled)
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('ᴋɪᴄᴋ ɴɢườɪ ᴅùɴɢ ᴋʜỏɪ sᴇʀᴠᴇʀ.')
    .addUserOption(o =>
      o.setName('ai_đó')
        .setDescription('ɴɢườɪ ᴅùɴɢ ᴄầɴ ʙị ᴋɪᴄᴋ.')
        .setRequired(true)
    ),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const user = interaction.options.getUser('ai_đó');

    if (user.id === interaction.user.id) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴛʜể ᴋɪᴄᴋ ᴄʜíɴʜ ᴍìɴʜ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (user.id === interaction.guild.ownerId) {
      return interaction.reply({
        content: '⛔ ᴋʜôɴɢ ᴛʜể ᴋɪᴄᴋ ᴄʜủ sᴇʀᴠᴇʀ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({
        content: '⚠️ ɴɢườɪ ɴàʏ ᴋʜôɴɢ ᴄòɴ ᴛʀᴏɴɢ sᴇʀᴠᴇʀ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (
      !botMember.permissions.has(PermissionFlagsBits.KickMembers) ||
      member.roles.highest.position >= botMember.roles.highest.position
    ) {
      return interaction.reply({
        content: '⛔ ʙᴏᴛ ᴋʜôɴɢ đủ ǫᴜʏềɴ ʜᴏặᴄ ᴠᴀɪ ᴛʀò ɴɢườɪ ɴàʏ ᴄᴀᴏ ʜơɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    interaction.client.kickState ??= new Map();
    interaction.client.kickState.set(interaction.id, {
      member
    });

    await interaction.reply({
      flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      components: [
        buildConfirmContainer(member),
        buildConfirmButtons()
      ],
      allowedMentions: { parse: [] }
    });
  },

  async handleButton(interaction) {
    const state = interaction.client.kickState?.get(
      interaction.message.interaction.id
    );
    if (!state) return interaction.deferUpdate();

    if (interaction.user.id !== interaction.message.interaction.user.id) {
      return interaction.reply({
        content: '❎ ʙạɴ ᴋʜôɴɢ ᴘʜảɪ ɴɢườɪ ɴʜấɴ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const { member } = state;

    if (interaction.customId === 'kick:cancel') {
      interaction.client.kickState.delete(interaction.message.interaction.id);

      return interaction.update({
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        components: [
          new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent('❎ ʜủʏ ʜàɴʜ độɴɢ ᴋɪᴄᴋ.')
          )
        ]
      });
    }

    try {
      await member.kick(`Kicked by ${interaction.user.tag}`);

      interaction.client.kickState.delete(interaction.message.interaction.id);

      await interaction.update({
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        components: [
          new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `✅ ᴋɪᴄᴋ **${member.user.tag}** ʀᴀ ᴋʜỏɪ sᴇʀᴠᴇʀ.\n` +
              `© ᴄᴏᴅᴇ ʙʏ ᴀɴᴘᴀʜɴ 🐧`
            )
          )
        ]
      });
    } catch (err) {
      console.error(err);

      await interaction.update({
        content: '❌ ᴋʜôɴɢ ᴛʜể ᴋɪᴄᴋ. ʜãʏ ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
        components: []
      });
    }
  }
};
*/