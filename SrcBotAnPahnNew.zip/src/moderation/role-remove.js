const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ComponentType,
  PermissionFlagsBits
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('role-remove')
    .setDescription('xóa ᴠᴀɪ ᴛʀò ᴋʜỏɪ ɴɢườɪ ᴅùɴɢ')
    .addUserOption(option =>
      option.setName('ai_đó')
        .setDescription('ɴɢườɪ ᴅùɴɢ ᴄầɴ xóa ᴠᴀɪ ᴛʀò')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('vai_trò')
        .setDescription('ᴠᴀɪ ᴛʀò ᴄầɴ xóa')
        .setRequired(true)),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const user = interaction.options.getUser('ai_đó');
    const role = interaction.options.getRole('vai_trò');

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({
        content: '⚠️ ᴋʜôɴɢ ᴛìᴍ ᴛʜấʏ ɴɢườɪ ᴅùɴɢ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (!member.roles.cache.has(role.id)) {
      return interaction.reply({
        content: '⚠️ ɴɢườɪ ᴅùɴɢ ɴàʏ ᴋʜôɴɢ ᴄó ᴠᴀɪ ᴛʀò ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (role.managed) {
      return interaction.reply({
        content: '🛡 ᴋʜôɴɢ ᴛʜể xóa ᴠᴀɪ ᴛʀò ᴄủᴀ ʙᴏᴛ / ʜệ ᴛʜốɴɢ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember) return;

    if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({
        content: '🛡 ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **MANAGE ROLES**.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (role.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: '🛡 ᴠᴀɪ ᴛʀò ɴàʏ ᴄᴀᴏ ʜơɴ ᴠᴀɪ ᴛʀò ᴄủᴀ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (member.roles.highest.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: '🛡 ᴋʜôɴɢ ᴛʜể xóa ᴠᴀɪ ᴛʀò ᴄủᴀ ɴɢườɪ ᴄó ᴠᴀɪ ᴛʀò ᴄᴀᴏ ʜơɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor('#ff9900')
      .setTitle('⚠️ xáᴄ ɴʜậɴ xóa ᴠᴀɪ ᴛʀò')
      .setDescription(
        `ʙạɴ sắᴘ xóa ᴠᴀɪ ᴛʀò:\n\n` +
        `👤 **ɴɢườɪ ᴅùɴɢ:** ${member}\n` +
        `🎭 **ᴠᴀɪ ᴛʀò:** ${role}`
      )
      .setFooter({ text: '© ᴄᴏᴅᴇ ʙʏ ᴀɴᴘᴀʜɴ 🐧' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_remove_role')
        .setLabel('Xáᴄ ɴʜậɴ')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('cancel_remove_role')
        .setLabel('ʜủʏ')
        .setStyle(ButtonStyle.Secondary)
    );

    const message = await interaction.reply({
      embeds: [confirmEmbed],
      components: [row],
      flags: MessageFlags.Ephemeral,
      fetchReply: true
    });

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 30_000,
      max: 1
    });

    collector.on('collect', async i => {
      if (i.user.id !== interaction.user.id) {
        return i.reply({
          content: '❎ ʙạɴ ᴋʜôɴɢ ᴘʜảɪ ɴɢườɪ ɴʜấɴ ʟệɴʜ ɴàʏ.',
          flags: MessageFlags.Ephemeral
        });
      }

      if (i.customId === 'cancel_remove_role') {
        return i.update({
          content: '❎ ʜủʏ ᴠɪệᴄ xóa ᴠᴀɪ ᴛʀò.',
          embeds: [],
          components: []
        });
      }

      try {
        await member.roles.remove(role);

        await i.update({
          embeds: [
            new EmbedBuilder()
              .setColor('Orange')
              .setDescription(`✅ xóa ᴠᴀɪ ᴛʀò ${role} ᴋʜỏɪ ${member}.`)
          ],
          components: []
        });
      } catch (err) {
        console.error(err);
        await i.update({
          content: '❎ ᴋʜôɴɢ ᴛʜể xóa ᴠᴀɪ ᴛʀò. ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʜạɴ ʙᴏᴛ.',
          embeds: [],
          components: []
        });
      }
    });

    collector.on('end', async (_, reason) => {
      if (reason === 'time') {
        await message.edit({
          content: '⏰ ʜếᴛ ᴛʜờɪ ɢɪᴀɴ xáᴄ ɴʜậɴ.',
          embeds: [],
          components: []
        }).catch(() => {});
      }
    });
  }
};