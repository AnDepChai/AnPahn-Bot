const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  MessageFlags
} = require("discord.js");

const config = require("../config.json");

function parseTime(input) {
  if (!input) return null;

  const match = input.toLowerCase().match(/^(\d+)(s|m|h|d)$/);
  if (!match) return null;

  const value = parseInt(match[1], 10);
  const unit = match[2];

  const map = {
    s: 1000,
    m: 60_000,
    h: 3_600_000,
    d: 86_400_000
  };

  const ms = value * map[unit];
  const MAX = 28 * 24 * 60 * 60 * 1000;

  if (ms > MAX) return "TOO_LONG";
  return ms;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("mute")
    .setDescription("ᴛạᴍ ᴛʜờɪ ᴋʜôɴɢ ᴄʜᴏ ɴɢườɪ ᴅùɴɢ ɴóɪ")
    .addUserOption(o =>
      o.setName("ai_đó")
        .setDescription("ɴɢườɪ ᴅùɴɢ ᴄầɴ ᴍᴜᴛᴇ")
        .setRequired(true))
    .addStringOption(o =>
      o.setName("thời_gian")
        .setDescription("ᴠᴅ: 10m, 2h, 1d")
        .setRequired(true))
    .addStringOption(o =>
      o.setName("lý_do")
        .setDescription("ʟý ᴅᴏ ᴍᴜᴛᴇ")
        .setRequired(false)),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const user = interaction.options.getUser("ai_đó");

    if (user.id === interaction.user.id) {
      return interaction.reply({
        content: "⚠️ ʙạɴ ᴋʜôɴɢ ᴛʜể ᴍᴜᴛᴇ ᴄʜíɴʜ ᴍìɴʜ.",
        flags: MessageFlags.Ephemeral
      });
    }

    if (user.bot) {
      return interaction.reply({
        content: "⚠️ ᴋʜôɴɢ ᴛʜể ᴍᴜᴛᴇ ʙᴏᴛ.",
        flags: MessageFlags.Ephemeral
      });
    }

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({
        content: "⚠️ ᴋʜôɴɢ ᴛìᴍ ᴛʜấʏ ɴɢườɪ ᴅùɴɢ.",
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({
        content: "⛔ ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **MODERATE MEMBERS**.",
        flags: MessageFlags.Ephemeral
      });
    }

    if (member.roles.highest.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: "🛡 ᴋʜôɴɢ ᴛʜể ᴍᴜᴛᴇ ɴɢườɪ ᴄó ᴠᴀɪ ᴛʀò ᴄᴀᴏ ʜơɴ ʙᴏᴛ.",
        flags: MessageFlags.Ephemeral
      });
    }

    if (member.isCommunicationDisabled()) {
      return interaction.reply({
        content: "⚠️ ɴɢườɪ ᴅùɴɢ ɴàʏ đã ʙị ᴍᴜᴛᴇ ᴛʀướᴄ đó.",
        flags: MessageFlags.Ephemeral
      });
    }

    const timeInput = interaction.options.getString("thời_gian");
    const duration = parseTime(timeInput);

    if (!duration) {
      return interaction.reply({
        content: "⚠️ ᴛʜờɪ ɢɪᴀɴ ᴋʜôɴɢ ʜợᴘ ʟệ (ᴠᴅ: 10m, 2h, 1d).",
        flags: MessageFlags.Ephemeral
      });
    }

    if (duration === "TOO_LONG") {
      return interaction.reply({
        content: "⛔ ᴛʜờɪ ɢɪᴀɴ ᴛốɪ đᴀ ʟà 28 ɴɢàʏ.",
        flags: MessageFlags.Ephemeral
      });
    }

    const reason =
      interaction.options.getString("lý_do") || "ᴋʜôɴɢ ᴄó ʟý ᴅᴏ ᴍᴜᴛᴇ.";

    try {
      await member.timeout(duration, reason);
    } catch (err) {
      console.error(err);
      return interaction.reply({
        content: "❎ ᴋʜôɴɢ ᴛʜể ᴍᴜᴛᴇ. ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.",
        flags: MessageFlags.Ephemeral
      });
    }

    const embed = new EmbedBuilder()
      .setColor(0xFF66CC)
      .addFields(
        { name: "👤 ɴɢườɪ ʙị ᴍᴜᴛᴇ", value: `${user}`, inline: true },
        { name: "⏱️ ᴛʜờɪ ɢɪᴀɴ", value: timeInput, inline: true },
        { name: "📌 ʟý ᴅᴏ", value: reason }
      )
      .setFooter({ text: "© ᴄᴏᴅᴇ ʙʏ ᴀɴ ᴘᴀʜɴ 🐧" })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed],
      flags: MessageFlags.Ephemeral
    });
  }
};