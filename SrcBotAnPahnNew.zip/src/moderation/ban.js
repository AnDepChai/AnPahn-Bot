const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ComponentType,
  PermissionsBitField
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('ʙᴀɴ ɴɢườɪ ᴅùɴɢ ᴋʜỏɪ sᴇʀᴠᴇʀ.')
    .addUserOption(o =>
      o.setName('ai_đó')
        .setDescription('ɴɢườɪ ᴅùɴɢ ᴄầɴ ʙị ʙᴀɴ.')
        .setRequired(true))
    .addStringOption(o =>
      o.setName('lý_do')
        .setDescription('ʟý ᴅᴏ ʙᴀɴ.'))
    .addIntegerOption(o =>
      o.setName('xoá_tin')
        .setDescription('xᴏá ᴛɪɴ ɴʜắɴ (0–7 ɴɢàʏ).')
        .setMinValue(0)
        .setMaxValue(7)),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const user = interaction.options.getUser('ai_đó');
    const reason = interaction.options.getString('lý_do') ?? 'ᴋʜôɴɢ ʟý ᴅᴏ';
    const days = interaction.options.getInteger('xoá_tin') ?? 0;

    if (user.id === interaction.user.id) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴛʜể ʙᴀɴ ᴄʜíɴʜ ᴍìɴʜ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (user.id === interaction.guild.ownerId) {
      return interaction.reply({
        content: '❌ ᴋʜôɴɢ ᴛʜể ʙᴀɴ **ᴄʜủ sᴇʀᴠᴇʀ**.',
        flags: MessageFlags.Ephemeral
      });
    }

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({
        content: '⚠️ ᴋʜôɴɢ ᴛìᴍ ᴛʜấʏ ɴɢườɪ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember) return;

    if (!botMember.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return interaction.reply({
        content: '❌ ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **BAN MEMBERS**.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (member.roles.highest.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: '❌ ʙᴏᴛ ᴋʜôɴɢ ᴛʜể ʙᴀɴ ɴɢườɪ ᴄó ᴠᴀɪ ᴛʀò ᴄᴀᴏ ʜơɴ ʜᴏặᴄ ʙằɴɢ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor('#ff9900')
      .setTitle('⚠️ xáᴄ ɴʜậɴ ʙᴀɴ')
      .setDescription(
        `👤 ɴɢườɪ ʙị ʙᴀɴ: ${user}\n` +
        `📝 ʟý ᴅᴏ: ${reason}\n` +
        `🗑️ xᴏá ᴛɪɴ: ${days} ɴɢàʏ`
      )
      .setFooter({ text: '© ᴄᴏᴅᴇ ʙʏ ᴀɴ ᴘᴀʜɴ 🐧' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_ban')
        .setLabel('Xác nhận')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('cancel_ban')
        .setLabel('Huỷ')
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({
      embeds: [confirmEmbed],
      components: [row],
      flags: MessageFlags.Ephemeral
    });

    const message = await interaction.fetchReply();

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 30_000,
      max: 1
    });

    collector.on('collect', async i => {
      if (i.user.id !== interaction.user.id) {
        return i.reply({
          content: '❌ ʙạɴ ᴋʜôɴɢ đượᴄ ᴘʜéᴘ sử ᴅụɴɢ ɴúᴛ ɴàʏ.',
          flags: MessageFlags.Ephemeral
        });
      }

      if (i.customId === 'cancel_ban') {
        return i.update({
          content: '❌ ʜuỷ ʙᴀɴ.',
          embeds: [],
          components: []
        });
      }

      try {
        await user.send(
          `🚫 ʙạɴ đã ʙị ʙᴀɴ ᴋʜỏɪ **${interaction.guild.name}**\n` +
          `📝 ʟý ᴅᴏ: ${reason}`
        ).catch(() => {});

        await member.ban({
          reason: `Banned by ${interaction.user.tag} - ${reason}`,
          deleteMessageSeconds: days * 86400
        });

        await i.update({
          embeds: [
            new EmbedBuilder()
              .setColor('#ff0000')
              .setDescription(`✅ ʙᴀɴ ${user} ᴛʜàɴʜ ᴄôɴɢ.`)
          ],
          components: []
        });
      } catch (err) {
        console.error(err);
        await i.update({
          content: '❌ ᴋʜôɴɢ ᴛʜể ʙᴀɴ. ʜãʏ ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
          embeds: [],
          components: []
        });
      }
    });
  }
};

/*
const {
  SlashCommandBuilder,
  MessageFlags,
  PermissionsBitField,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

const config = require('../config.json');

function buildConfirmContainer(user, reason, days) {
  return new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# ⚠️ xáᴄ ɴʜậɴ ʙᴀɴ\n` +
        `👤 **ɴɢườɪ ʙị ʙᴀɴ:** ${user}\n` +
        `📝 **ʟý ᴅᴏ:** ${reason}\n` +
        `🗑️ **xᴏá ᴛɪɴ:** ${days} ɴɢàʏ`
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        '© ᴄᴏᴅᴇ ʙʏ ᴀɴ ᴘᴀʜɴ 🐧'
      )
    );
}

function buildConfirmButtons(disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ban:confirm')
      .setLabel('Xác nhận')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(disabled),

    new ButtonBuilder()
      .setCustomId('ban:cancel')
      .setLabel('Huỷ')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled)
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('ʙᴀɴ ɴɢườɪ ᴅùɴɢ ᴋʜỏɪ sᴇʀᴠᴇʀ.')
    .addUserOption(o =>
      o.setName('ai_đó')
        .setDescription('ɴɢườɪ ᴅùɴɢ ᴄầɴ ʙị ʙᴀɴ.')
        .setRequired(true)
    )
    .addStringOption(o =>
      o.setName('lý_do')
        .setDescription('ʟý ᴅᴏ ʙᴀɴ.')
    )
    .addIntegerOption(o =>
      o.setName('xoá_tin')
        .setDescription('xᴏá ᴛɪɴ ɴʜắɴ (0–7 ɴɢàʏ).')
        .setMinValue(0)
        .setMaxValue(7)
    ),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const user = interaction.options.getUser('ai_đó');
    const reason = interaction.options.getString('lý_do') ?? 'ᴋʜôɴɢ ʟý ᴅᴏ';
    const days = interaction.options.getInteger('xoá_tin') ?? 0;

    if (user.id === interaction.user.id) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴛʜể ʙᴀɴ ᴄʜíɴʜ ᴍìɴʜ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (user.id === interaction.guild.ownerId) {
      return interaction.reply({
        content: '❌ ᴋʜôɴɢ ᴛʜể ʙᴀɴ **ᴄʜủ sᴇʀᴠᴇʀ**.',
        flags: MessageFlags.Ephemeral
      });
    }

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({
        content: '⚠️ ᴋʜôɴɢ ᴛìᴍ ᴛʜấʏ ɴɢườɪ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return interaction.reply({
        content: '❌ ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **BAN MEMBERS**.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (member.roles.highest.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: '❌ ʙᴏᴛ ᴋʜôɴɢ ᴛʜể ʙᴀɴ ɴɢườɪ ᴄó ᴠᴀɪ ᴛʀò ᴄᴀᴏ ʜơɴ ʜᴏặᴄ ʙằɴɢ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    interaction.client.banState ??= new Map();
    interaction.client.banState.set(interaction.id, {
      user,
      member,
      reason,
      days
    });

    await interaction.reply({
      flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      components: [
        buildConfirmContainer(user, reason, days),
        buildConfirmButtons()
      ],
      allowedMentions: { parse: [] }
    });
  },

  async handleButton(interaction) {
    const state = interaction.client.banState?.get(
      interaction.message.interaction.id
    );
    if (!state) return interaction.deferUpdate();

    const { user, member, reason, days } = state;

    if (interaction.user.id !== interaction.message.interaction.user.id) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ đượᴄ ᴘʜéᴘ sử ᴅụɴɢ ɴúᴛ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (interaction.customId === 'ban:cancel') {
      interaction.client.banState.delete(interaction.message.interaction.id);

      return interaction.update({
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        components: [
          new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent('❌ ʜuỷ ʙᴀɴ.')
          )
        ]
      });
    }

    try {
      await user.send(
        `🚫 ʙạɴ đã ʙị ʙᴀɴ ᴋʜỏɪ **${interaction.guild.name}**\n` +
        `📝 ʟý ᴅᴏ: ${reason}`
      ).catch(() => {});

      await member.ban({
        reason: `Banned by ${interaction.user.tag} - ${reason}`,
        deleteMessageSeconds: days * 86400
      });

      interaction.client.banState.delete(interaction.message.interaction.id);

      await interaction.update({
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        components: [
          new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `✅ ʙᴀɴ ${user} ᴛʜàɴʜ ᴄôɴɢ.`
            )
          )
        ]
      });
    } catch (err) {
      console.error(err);

      await interaction.update({
        content: '❌ ᴋʜôɴɢ ᴛʜể ʙᴀɴ. ʜãʏ ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
        components: []
      });
    }
  }
};
*/