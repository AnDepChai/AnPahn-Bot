const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ComponentType,
  PermissionFlagsBits
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('role-add')
    .setDescription('ᴛʀᴀᴏ ᴠᴀɪ ᴛʀò ᴄʜᴏ ᴍộᴛ ɴɢườɪ.')
    .addUserOption(option =>
      option.setName('ai_đó')
        .setDescription('ɴɢườɪ ɴʜậɴ ᴠᴀɪ ᴛʀò.')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('vai_trò')
        .setDescription('ᴠᴀɪ ᴛʀò ᴍᴜốɴ ᴛʀᴀᴏ.')
        .setRequired(true)),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const member = interaction.options.getMember('ai_đó');
    const role = interaction.options.getRole('vai_trò');

    if (!member) {
      return interaction.reply({
        content: '⚠️ ᴋʜôɴɢ ᴛìᴍ ᴛʜấʏ ɴɢườɪ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (role.managed) {
      return interaction.reply({
        content: '⛔ ᴋʜôɴɢ ᴛʜể ᴛʀᴀᴏ ᴠᴀɪ ᴛʀò ʜệ ᴛʜốɴɢ / ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember) return;

    if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({
        content: '⛔ ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **MANAGE ROLES**.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (role.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: '⛔ ᴠᴀɪ ᴛʀò ɴàʏ ᴄᴀᴏ ʜơɴ ǫᴜʏềɴ ᴄủᴀ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (member.roles.highest.position >= botMember.roles.highest.position) {
      return interaction.reply({
        content: '⛔ ᴋʜôɴɢ ᴛʜể ᴛʀᴀᴏ ᴠᴀɪ ᴛʀò ᴄʜᴏ ɴɢườɪ ᴄó ᴠᴀɪ ᴛʀò ᴄᴀᴏ ʜơɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (member.roles.cache.has(role.id)) {
      return interaction.reply({
        content: '⚠️ ɴɢườɪ ɴàʏ đã ᴄó ᴠᴀɪ ᴛʀò ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor('#ffcc00')
      .setTitle('⚠️ xáᴄ ɴʜậɴ ᴛʀᴀᴏ ᴠᴀɪ ᴛʀò')
      .setDescription(
        `ʙạɴ ᴄó ᴄʜắᴄ ᴄʜắɴ ᴍᴜốɴ ᴛʀᴀᴏ:\n\n` +
        `👤 ɴɢườɪ ɴʜậɴ: ${member}\n` +
        `🎭 ᴠᴀɪ ᴛʀò: ${role}`
      )
      .setFooter({ text: '© ᴄᴏᴅᴇ ʙʏ ᴀɴ ᴘᴀʜɴ 🐧' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_role')
        .setLabel('Xác nhận')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('cancel_role')
        .setLabel('Huỷ')
        .setStyle(ButtonStyle.Danger)
    );

    const message = await interaction.reply({
      embeds: [confirmEmbed],
      components: [row],
      flags: MessageFlags.Ephemeral,
      fetchReply: true
    });

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 30_000,
      max: 1
    });

    collector.on('collect', async i => {
      if (i.user.id !== interaction.user.id) {
        return i.reply({
          content: '❌ ʙạɴ ᴋʜôɴɢ đượᴄ ᴘʜéᴘ sử ᴅụɴɢ núᴛ ɴàʏ.',
          flags: MessageFlags.Ephemeral
        });
      }

      if (i.customId === 'cancel_role') {
        return i.update({
          content: '❌ ʜủʏ ᴛʀᴀᴏ ᴠᴀɪ ᴛʀò',
          embeds: [],
          components: []
        });
      }

      try {
        await member.roles.add(role);

        await i.update({
          embeds: [
            new EmbedBuilder()
              .setColor('Green')
              .setDescription(`✅ ᴛʀᴀᴏ ᴄʜᴏ ${member} ᴠᴀɪ ᴛʀò ${role} ᴛʜàɴʜ ᴄôɴɢ.`)
          ],
          components: []
        });
      } catch (err) {
        console.error(err);
        await i.update({
          content: '❌ ᴋʜôɴɢ ᴛʜể ᴛʀᴀᴏ ᴠᴀɪ ᴛʀò. ʜãʏ ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
          embeds: [],
          components: []
        });
      }
    });

    collector.on('end', async (_, reason) => {
      if (reason === 'time') {
        await message.edit({
          content: '⌛ ʜếᴛ ᴛʜờɪ ɢɪᴀɴ xáᴄ ɴʜậɴ. ʜàɴʜ độɴɢ đã ʙị ʜᴜỷ.',
          embeds: [],
          components: []
        }).catch(() => {});
      }
    });
  }
};
