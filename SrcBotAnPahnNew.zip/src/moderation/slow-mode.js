const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  ChannelType,
  MessageFlags
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slow-mode')
    .setDescription('⏱️ ʙậᴛ / ᴛắᴛ sʟᴏᴡ ᴍᴏᴅᴇ ᴋêɴʜ')
    .addIntegerOption(option =>
      option
        .setName('thời_gian')
        .setDescription('ᴛʜờɪ ɢɪᴀɴ sʟᴏᴡ ᴍᴏᴅᴇ (ɢɪâʏ)')
        .setMinValue(0)
        .setMaxValue(21600)
    )
    .addBooleanOption(option =>
      option
        .setName('tắt')
        .setDescription('ᴛắᴛ ᴄʜế độ ᴄʜậᴍ')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const time = interaction.options.getInteger('thời_gian');
    const off = interaction.options.getBoolean('tắt') === true;
    const channel = interaction.channel;

    if (!channel || channel.type !== ChannelType.GuildText) {
      return interaction.reply({
        content: '❎ ʟệɴʜ ɴàʏ ᴄʜỉ sử ᴅụɴɢ ᴛʀᴏɴɢ ᴋêɴʜ ᴠăɴ ʙảɴ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({
        content: '🛡 ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **MANAGE CHANNELS**.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (!off && (time === null || time < 0)) {
      return interaction.reply({
        content: '⚠️ ʜãʏ ɴʜậᴘ **ᴛʜờɪ ɢɪᴀɴ** ʜợᴘ ʟệ ʜᴏặᴄ ᴄʜọɴ **ᴛắᴛ**.',
        flags: MessageFlags.Ephemeral
      });
    }

    try {
      if (off || time === 0) {
        await channel.setRateLimitPerUser(0);

        const embed = new EmbedBuilder()
          .setColor('#00ff99')
          .setTitle('✅ ᴛắᴛ ᴄʜế độ ᴄʜậᴍ')
          .setDescription(
            `📝 **ᴋêɴʜ:** ${channel}\n` +
            `🔓 **ᴛʀạɴɢ ᴛʜáɪ:** ᴛắᴛ`
          )
          .setFooter({ text: `ʙởɪ ${interaction.user.tag}` })
          .setTimestamp();

        return interaction.reply({
          embeds: [embed],
          flags: MessageFlags.Ephemeral
        });
      }

      await channel.setRateLimitPerUser(time);

      const embed = new EmbedBuilder()
        .setColor('#ffcc00')
        .setTitle('⏱ ᴄʜế độ ᴄʜậᴍ')
        .setDescription(
          `📝 **ᴋêɴʜ:** ${channel}\n` +
          `⏰ **ᴛʜờɪ ɢɪᴀɴ:** ${time} ɢɪâʏ`
        )
        .setFooter({ text: `ʙởɪ ${interaction.user.tag}` })
        .setTimestamp();

      return interaction.reply({
        embeds: [embed],
        flags: MessageFlags.Ephemeral
      });

    } catch (err) {
      console.error(err);
      return interaction.reply({
        content: '❎ ᴋʜôɴɢ ᴛʜể ᴛʜᴀʏ đổi sʟᴏᴡ ᴍᴏᴅᴇ. ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }
  }
};