const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  ChannelType,
  MessageFlags
} = require('discord.js');

const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('🔒 ᴋʜᴏá ᴄʜᴀᴛ ᴋêɴʜ')
    .addChannelOption(option =>
      option
        .setName('kênh')
        .setDescription('ᴄʜọɴ ᴋêɴʜ ᴄầɴ ᴋʜᴏá (ʙỏ ᴛʀốɴɢ = ᴋêɴʜ ʜɪệɴ ᴛạɪ)')
        .addChannelTypes(ChannelType.GuildText)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const channel =
      interaction.options.getChannel('kênh') || interaction.channel;

    if (!channel || !channel.isTextBased()) {
      return interaction.reply({
        content: '❌ ᴋêɴʜ ᴋʜôɴɢ ʜợᴘ ʟệ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({
        content: '⛔ ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **MANAGE CHANNELS**.',
        flags: MessageFlags.Ephemeral
      });
    }

    const everyoneOverwrite = channel.permissionOverwrites.cache.get(
      interaction.guild.roles.everyone.id
    );

    if (everyoneOverwrite?.deny.has(PermissionFlagsBits.SendMessages)) {
      return interaction.reply({
        content: '🔒 ᴋêɴʜ ɴàʏ đã ʙị ᴋʜᴏá ᴛʀướᴄ đó.',
        flags: MessageFlags.Ephemeral
      });
    }

    try {
      await channel.permissionOverwrites.edit(
        interaction.guild.roles.everyone,
        { SendMessages: false }
      );
    } catch (err) {
      console.error(err);
      return interaction.reply({
        content: '❌ ᴋʜôɴɢ ᴛʜể ᴋʜᴏá ᴋêɴʜ. ʜãʏ ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const embed = new EmbedBuilder()
      .setColor('#ff5555')
      .setTitle('🔒 ᴋʜᴏá ᴄʜᴀᴛ')
      .setDescription(
        `📢 **ᴋêɴʜ:** ${channel}\n` +
        `🔐 **ᴛʀạɴɢ ᴛʜáɪ:** ᴋʜᴏá`
      )
      .setFooter({ text: `ʙởɪ ${interaction.user.tag}` })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed]
    });
  }
};

/*
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize
} = require('discord.js');

const config = require('../config.json');

function buildLockContainer(channel, moderator) {
  return new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# 🔒 ᴋʜᴏá ᴄʜᴀᴛ\n\n` +
        `📢 **ᴋêɴʜ:** ${channel}\n` +
        `🔐 **ᴛʀạɴɢ ᴛʜáɪ:** ᴋʜᴏá`
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `👮 **ᴛʜựᴄ ʜɪệɴ:** ${moderator.tag}\n` +
        `© ᴄᴏᴅᴇ ʙʏ ᴀɴᴘᴀʜɴ 🐧`
      )
    );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('🔒 ᴋʜᴏá ᴄʜᴀᴛ ᴋêɴʜ.')
    .addChannelOption(option =>
      option
        .setName('kênh')
        .setDescription('ᴄʜọɴ ᴋêɴʜ ᴄầɴ ᴋʜᴏá (ʙỏ ᴛʀốɴɢ = ᴋêɴʜ ʜɪệɴ ᴛạɪ).')
        .addChannelTypes(ChannelType.GuildText)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const ownerIDs = Array.isArray(config.OwnerIDs) ? config.OwnerIDs : [];

    if (!ownerIDs.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ ʙạɴ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ sử ᴅụɴɢ ʟệɴʜ ɴàʏ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const channel =
      interaction.options.getChannel('kênh') || interaction.channel;

    if (!channel || channel.type !== ChannelType.GuildText) {
      return interaction.reply({
        content: '❌ ᴋêɴʜ ᴋʜôɴɢ ʜợᴘ ʟệ.',
        flags: MessageFlags.Ephemeral
      });
    }

    const botMember = interaction.guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({
        content: '⛔ ʙᴏᴛ ᴋʜôɴɢ ᴄó ǫᴜʏềɴ **MANAGE CHANNELS**.',
        flags: MessageFlags.Ephemeral
      });
    }

    const everyoneOverwrite = channel.permissionOverwrites.cache.get(
      interaction.guild.roles.everyone.id
    );

    if (everyoneOverwrite?.deny.has(PermissionFlagsBits.SendMessages)) {
      return interaction.reply({
        content: '🔒 ᴋêɴʜ ɴàʏ đã ʙị ᴋʜᴏá ᴛʀướᴄ đó.',
        flags: MessageFlags.Ephemeral
      });
    }

    try {
      await channel.permissionOverwrites.edit(
        interaction.guild.roles.everyone,
        { SendMessages: false }
      );
    } catch (err) {
      console.error(err);
      return interaction.reply({
        content: '❌ ᴋʜôɴɢ ᴛʜể ᴋʜᴏá ᴋêɴʜ. ʜãʏ ᴋɪểᴍ ᴛʀᴀ ǫᴜʏềɴ ʙᴏᴛ.',
        flags: MessageFlags.Ephemeral
      });
    }

    await interaction.reply({
      flags: MessageFlags.IsComponentsV2,
      components: [
        buildLockContainer(channel, interaction.user)
      ],
      allowedMentions: { parse: [] }
    });
  }
};
*/