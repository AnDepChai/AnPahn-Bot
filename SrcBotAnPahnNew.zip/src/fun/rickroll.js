const {
  SlashCommandBuilder,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rickroll')
    .setDescription('Never gonna give you up'),

  async execute(interaction) {
    const roll = [
      'Never gonna give you up',
      'Never gonna let you down',
      'Never gonna run around and desert you',
      'Never gonna make you cry',
      'Never gonna say goodbye',
      'Never gonna tell a lie and hurt you'
    ];

    const rick = roll[Math.floor(Math.random() * roll.length)];

    const container = new ContainerBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `# 😂・${rick}`
        )
      )
      .addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(
            'https://i.pinimg.com/originals/88/82/bc/8882bcf327896ab79fb97e85ae63a002.gif'
          )
        )
      );

    await interaction.reply({
      flags: MessageFlags.IsComponentsV2,
      components: [container],
      allowedMentions: { parse: [] }
    });
  }
};