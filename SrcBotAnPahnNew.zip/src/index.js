require('dotenv').config({ quiet: true });
const config = require('./config.json');

const {
  Client,
  GatewayIntentBits,
  Partials,
  Collection,
  MessageFlags,
  ActivityType,
  Events,
  REST,
  Routes,
  ComponentType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  UserSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
} = require("discord.js");


const {
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  ThumbnailBuilder,
} = require("@discordjs/builders");


const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  NoSubscriberBehavior
} = require("@discordjs/voice");

const path = require("path");
const fs = require("fs");
const chalk = require("chalk");
const gradient = require("gradient-string");
const boxen = require("boxen");

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildPresences,
    ],
    partials: [
        Partials.Message,
        Partials.Channel,
        Partials.Reaction,
    ],
});

const AutoModManager = require('./automod/AutoModManager');

client.commands = new Collection();

const commandDirs = ["commands", "moderation", "fun"];

for (const dir of commandDirs) {
    const folder = path.join(__dirname, dir);
    if (!fs.existsSync(folder)) continue;

    const files = fs.readdirSync(folder).filter(f => f.endsWith(".js"));
    for (const file of files) {
        const command = require(path.join(folder, file));
        if (command?.data?.name) {
            client.commands.set(command.data.name, command);
        }
    }
}

const eventsPath = path.join(__dirname, "events");
if (fs.existsSync(eventsPath)) {
    for (const file of fs.readdirSync(eventsPath).filter(f => f.endsWith(".js"))) {
        const event = require(path.join(eventsPath, file));
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
    }
}

client.once(Events.ClientReady, async () => {

    await loadingBar();

    const banner = `
 ____  _____  ____      __    _  _    ____   __    _   _  _  _ 
(  _ \\(  _  )(_  _)    /__\\  ( \\( )  (  _ \\ /__\\  ( )_( )( \\( )
 ) _ < )(_)(   )(     /(__)\\  )  (    )___//(__)\\  ) _ (  )  ( 
(____/(_____) (__)   (__)(__)(_)\_)  (__) (__)(__)(_) (_)(_)\\_)
    `;

    const output = boxen(
        gradient.rainbow.multiline(banner) +
        chalk.cyan("\nVersion: 4.1.7\nCre: AnPahn\n"),
        {
            padding: 1,
            borderStyle: "double",
            borderColor: "cyan",
            align: "center"
        }
    );

    console.log("\n\n");
    console.log(output);
    console.log(chalk.green("✅ 𝙱𝚘𝚝 𝙰𝚗𝙿𝚊𝚑𝚗 𝙾𝚗𝚕𝚒𝚗𝚎"));

    recalcTotalMembers();

    client.user.setStatus("dnd");

    updateActivity();
    setInterval(updateActivity, 5 * 60 * 1000);

    await registerSlashCommands();
client.autoMod = new AutoModManager(client, config);

});

client.on('interactionCreate', async interaction => {
  try {

    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command?.execute) {
        return interaction.reply({
          content: '❌ 𝙻ệ𝚗𝚑 𝙺𝚑ô𝚗𝚐 𝚃ồ𝚗 𝚃ạ𝚒!',
          flags: MessageFlags.Ephemeral
        });
      }
      return await command.execute(interaction);
    }

    if (interaction.isButton()) {
      const [module] = interaction.customId.split(':');
      const command = client.commands.get(module);

      if (!command?.handleButton) {
        return interaction.reply({
          content: '❌ 𝙽ú𝚝 𝙽à𝚢 𝙺𝚑ô𝚗𝚐 𝙲ò𝚗 𝙷𝚒ệ𝚞 𝙻ự𝚌!',
          flags: MessageFlags.Ephemeral
        });
      }

      await command.handleButton(interaction);

      if (!interaction.replied && !interaction.deferred) {
        await interaction.deferUpdate().catch(() => {});
      }

      return;
    }

    if (interaction.isAnySelectMenu()) {
      const [module] = interaction.customId.split(':');
      const command = client.commands.get(module);

      if (!command?.handleSelect) {
        return interaction.reply({
          content: '❌ 𝙼𝚎𝚗𝚞 𝙽à𝚢 𝙺𝚑ô𝚗𝚐 𝙲ò𝚗 𝙷𝚒ệ𝚞 𝙻ự𝚌!',
          flags: MessageFlags.Ephemeral
        });
      }

      await command.handleSelect(interaction);

      if (!interaction.replied && !interaction.deferred) {
        await interaction.deferUpdate().catch(() => {});
      }

      return;
    }

    if (interaction.isModalSubmit()) {
      const [module] = interaction.customId.split(':');
      const command = client.commands.get(module);

      if (!command?.handleModal) {
        return interaction.deferUpdate().catch(() => {});
      }

      await command.handleModal(interaction);

      if (!interaction.replied && !interaction.deferred) {
        await interaction.deferUpdate().catch(() => {});
      }

      return;
    }

  } catch (err) {
    console.error('Interaction error:', err);

    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: '❌ 𝙲ó 𝙻ỗ𝚒 𝚇ả𝚢 𝚁𝚊 𝙺𝚑𝚒 𝚃𝚑ự𝚌 𝚃𝚑𝚒 𝙻ệ𝚗𝚑 𝙽à𝚢!',
        flags: MessageFlags.Ephemeral
      }).catch(() => {});
    }
  }
});

const statuses = [
    { type: ActivityType.Playing, text: "với ! An Pahn | /Help" },
    { type: ActivityType.Watching, text: "! An Pahn Code | /Help" },
    { type: ActivityType.Watching, text: "{users} người dùng | /Help" }
];

let statusIndex = 0;
let totalMembers = 0;

function updateActivity() {
    const s = statuses[statusIndex];
    client.user.setActivity(
        s.text.replace("{users}", totalMembers.toLocaleString()),
        { type: s.type }
    );
    statusIndex = (statusIndex + 1) % statuses.length;
}

function recalcTotalMembers() {
    totalMembers = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);
}

async function registerSlashCommands() {
    const rest = new REST({ version: "10" }).setToken(process.env.TOKEN);
    const body = client.commands.map(c => c.data);

    await rest.put(
        Routes.applicationCommands(client.user.id),
        { body }
    );

    console.log(chalk.green("✅ 𝙻ệ𝚗𝚑 𝚂𝚕𝚊𝚜𝚑 𝙲ậ𝚙 𝙽𝚑ậ𝚝!"));
}

async function loadingBar() {
    const len = 30;
    process.stdout.write("\n");
    for (let i = 0; i <= len; i++) {
        const bar = "█".repeat(i) + "-".repeat(len - i);
        process.stdout.write(
            `\r${chalk.cyan("ĐANG LOADING:")} [${gradient.rainbow(bar)}] ${Math.round(i / len * 100)}%`
        );
        await new Promise(r => setTimeout(r, 80));
    }
    console.log();
}


client.login(process.env.TOKEN);