const {
  SlashCommandBuilder,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  SectionBuilder,
  ThumbnailBuilder
} = require('discord.js');

const axios = require('axios');

const cache = new Map();
const CACHE_MS = 5000;
const BUTTON_LIFETIME = 15000;

async function buildPingPayload(client, user, disabled = false) {
  const wsPing = Math.round(client.ws.ping);

  const start = Date.now();
  await new Promise(r => setTimeout(r, 1));
  const botLatency = Date.now() - start;

  let networkLatency = 'Null';
  try {
    const t = Date.now();
    await axios.get('https://discord.com', { timeout: 3000 });
    networkLatency = `${Date.now() - t}ms`;
  } catch {}

  const headerSection = new SectionBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# 📶 ᴘɪɴɢ ʙᴏᴛ\n🏓 ᴘᴏɴɢ!`
      )
    )
    .setThumbnailAccessory(
      new ThumbnailBuilder().setURL(
        user.displayAvatarURL({ size: 256 })
      )
    );

  const statsText = new TextDisplayBuilder().setContent(
    `⏱️ **ᴛʀễ ʙᴏᴛ:** \`${botLatency}ms\`\n` +
    `🌐 **ᴛʀễ ᴀᴘɪ:** \`${wsPing}ms\`\n` +
    `📡 **ᴛʀễ ᴍạɴɢ:** \`${networkLatency}\``
  );

  const footerText = new TextDisplayBuilder().setContent(
    `© ᴄᴏᴅᴇ ʙʏ ᴀɴᴘᴀʜɴ 🐧`
  );

  const container = new ContainerBuilder()
    .addSectionComponents(headerSection)
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(statsText)
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(footerText);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ping:refresh')
      .setLabel(disabled ? 'Expired' : 'Làm mới')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(disabled),

    new ButtonBuilder()
      .setCustomId('ping:close')
      .setLabel('Đóng')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(disabled)
  );

  return [container, row];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('ᴋɪểᴍ ᴛʀᴀ độ ᴛʀễ ᴄủᴀ ʙᴏᴛ ᴠà ᴀᴘɪ.'),

  async execute(interaction) {
    await interaction.deferReply({
      flags: MessageFlags.IsComponentsV2
    });

    const payload = await buildPingPayload(
      interaction.client,
      interaction.user
    );

    await interaction.editReply({
      flags: MessageFlags.IsComponentsV2,
      components: payload
    });

    cache.set(interaction.id, {
      time: Date.now(),
      userId: interaction.user.id
    });

    setTimeout(async () => {
      try {
        const disabledPayload = await buildPingPayload(
          interaction.client,
          interaction.user,
          true
        );

        await interaction.editReply({
          flags: MessageFlags.IsComponentsV2,
          components: disabledPayload
        });
      } catch {}
    }, BUTTON_LIFETIME);
  },

  async handleButton(interaction) {
    const originId = interaction.message.interaction?.id;
    if (!originId) return;

    const meta = cache.get(originId);
    if (!meta) return;

    if (interaction.user.id !== meta.userId) {
      return interaction.reply({
        content: '❌ 𝙱ạ𝚗 𝙺𝚑ô𝚗𝚐 𝙿𝚑ả𝚒 𝙽𝚐ườ𝚒 𝙳ù𝚗𝚐 𝙻ệ𝚗𝚑 𝙽à𝚢!',
        flags: MessageFlags.Ephemeral
      });
    }

    if (interaction.customId === 'ping:refresh') {
      await interaction.deferUpdate();

      if (Date.now() - meta.time < CACHE_MS) return;

      const payload = await buildPingPayload(
        interaction.client,
        interaction.user
      );

      cache.set(originId, {
        time: Date.now(),
        userId: meta.userId
      });

      return interaction.editReply({
        flags: MessageFlags.IsComponentsV2,
        components: payload
      });
    }

    if (interaction.customId === 'ping:close') {
      await interaction.deferUpdate();
      cache.delete(originId);
      return interaction.deleteReply();
    }
  }
};