const {
  SlashCommandBuilder,
  MessageFlags,
  PermissionsBitField,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');

function sanitize(str = '') {
  return str
    .replace(/@everyone/gi, '[everyone]')
    .replace(/@here/gi, '[here]')
    .replace(/<@&\d+>/g, '[role]')
    .replace(/<@!?(\d+)>/g, '[user]')
    .replace(/```/g, 'ʼʼʼ')
    .replace(/\|\|/g, '');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bot-say')
    .setDescription('ʙᴏᴛ ɴᴏ́ɪ ʟᴀ̣ɪ ɴᴏ̣̂ɪ ᴅᴜɴɢ ʙᴀ̣ɴ ɢᴜ̛̉ɪ.')
    .addStringOption(option =>
      option
        .setName('text')
        .setDescription('ɴᴏ̣̂ɪ ᴅᴜɴɢ (ᴛᴜ̀ʏ ᴄʜᴏ̣ɴ).')
        .setRequired(false)
    )
    .addAttachmentOption(option =>
      option
        .setName('file')
        .setDescription('ᴀ̉ɴʜ / ᴠɪᴅᴇᴏ (ᴛᴜ̀ʏ ᴄʜᴏ̣ɴ).')
        .setRequired(false)
    ),

  async execute(interaction) {
    const channel = interaction.channel;
    if (!channel?.isTextBased()) return;

    const perms = channel.permissionsFor(interaction.guild.members.me);
    if (!perms?.has(PermissionsBitField.Flags.SendMessages)) return;

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const text = sanitize(interaction.options.getString('text') || '');
    const attachment = interaction.options.getAttachment('file');

    if (!text && !attachment) {
      return interaction.deleteReply().catch(() => {});
    }

    const container = new ContainerBuilder();

    if (text) {
      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(text)
      );

      container.addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      );
    }

    if (attachment) {
      container.addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(attachment.url)
        )
      );
    }

    const sent = await channel.send({
      flags: MessageFlags.IsComponentsV2,
      components: [container],
      allowedMentions: { parse: [] }
    });

    await interaction.deleteReply().catch(() => {});
  }
};