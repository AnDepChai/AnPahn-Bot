/*
const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  MessageFlags
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('ʜɪểɴ ᴛʜị ᴀᴠᴀᴛᴀʀ ᴄủᴀ ᴍộᴛ ɴɢườɪ ᴅùɴɢ.')
    .addUserOption(option =>
      option
        .setName('ai_đó')
        .setDescription('ɴɢườɪ ᴅùɴɢ ʙạɴ ᴍᴜốɴ ʟấʏ ᴀᴠᴀᴛᴀʀ')
    ),

  async execute(interaction) {
    const user = interaction.options.getUser('ai_đó') || interaction.user;

    const avatarLarge = user.displayAvatarURL({
      size: 1024,
      extension: 'png',
      forceStatic: false
    });

    const avatarSmall = user.displayAvatarURL({
      size: 64,
      extension: 'png',
      forceStatic: false
    });

    const embed = new EmbedBuilder()
      .setAuthor({
        name: user.tag,
        iconURL: avatarSmall
      })
      .setImage(avatarLarge)
      .setColor(0x2e3b46)
      .setFooter({
        text: '© ᴄᴏᴅᴇ ʙʏ ᴀɴ ᴘᴀʜɴ 🐧'
      })
      .setTimestamp();

    const openButton = new ButtonBuilder()
      .setLabel('Open Avatar')
      .setStyle(ButtonStyle.Link)
      .setURL(avatarLarge);

    const copyButton = new ButtonBuilder()
      .setCustomId('copy_avatar')
      .setLabel('Copy Link')
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder().addComponents(openButton, copyButton);

    await interaction.reply({
      embeds: [embed],
      components: [row]
    });

    const message = await interaction.fetchReply();

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60_000,
      filter: i => i.user.id === interaction.user.id
    });

    collector.on('collect', async i => {
      if (i.customId !== 'copy_avatar') return;

      await i.reply({
        content: `🔗 ᴀᴠᴀᴛᴀʀ ʟɪɴᴋ:\n${avatarLarge}`,
        flags: MessageFlags.Ephemeral
      });
    });

    collector.on('end', async () => {
      if (!message.editable) return;

      try {
        const disabledRow = new ActionRowBuilder().addComponents(
          ButtonBuilder.from(openButton).setDisabled(true),
          ButtonBuilder.from(copyButton).setDisabled(true)
        );

        await message.edit({ components: [disabledRow] });
      } catch {}
    });
  }
};
*/

const {
  SlashCommandBuilder,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder
} = require('discord.js');

const EXPIRE_TIME = 60_000;

const SIZE_OPTIONS = [64, 128, 256, 512, 1024, 2048, 4096];

function buildPayload(user, size) {
  const avatarURL = user.displayAvatarURL({
    size,
    forceStatic: false
  });

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# 🖼️ ${user.tag}`
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(avatarURL)
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `🔗 **ʟɪɴᴋ:**\n${avatarURL}`
      )
    );

  const sizeMenu = new StringSelectMenuBuilder()
    .setCustomId('avatar:size')
    .setPlaceholder('📐 Chọn kích thước ảnh')
    .addOptions(
      SIZE_OPTIONS.map(v => ({
        label: `${v} x ${v}`,
        value: String(v),
        default: v === size
      }))
    );

  const menuRow = new ActionRowBuilder().addComponents(sizeMenu);

  const linkRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Open Avatar')
      .setStyle(ButtonStyle.Link)
      .setURL(avatarURL)
  );

  return {
    container,
    rows: [menuRow, linkRow]
  };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('ʜɪểɴ ᴛʜị ᴀᴠᴀᴛᴀʀ ᴄủᴀ ᴍộᴛ ɴɢườɪ ᴅùɴɢ.')
    .addUserOption(option =>
      option
        .setName('ai_đó')
        .setDescription('ɴɢườɪ ᴅùɴɢ ʙạɴ ᴍᴜốɴ ʟấʏ ᴀᴠᴀᴛᴀʀ.')
        .setRequired(false)
    ),

  async execute(interaction) {
    const user = interaction.options.getUser('ai_đó') || interaction.user;
    const size = 1024;

    const payload = buildPayload(user, size);

    await interaction.reply({
      flags: MessageFlags.IsComponentsV2,
      components: [payload.container, ...payload.rows],
      allowedMentions: { parse: [] }
    });

    interaction.client.avatarCache ??= new Map();
    interaction.client.avatarCache.set(interaction.id, {
      userId: user.id,
      size
    });

    setTimeout(async () => {
      try {
        const disabledRows = payload.rows.map(r => {
          const row = ActionRowBuilder.from(r);
          row.components.forEach(c => c.setDisabled?.(true));
          return row;
        });

        await interaction.editReply({
          flags: MessageFlags.IsComponentsV2,
          components: [payload.container, ...disabledRows]
        });
      } catch {}
    }, EXPIRE_TIME);
  },

  async handleSelect(interaction) {
    if (interaction.customId !== 'avatar:size') return;

    const originId = interaction.message.interaction?.id;
    if (!originId) return;

    const cache = interaction.client.avatarCache?.get(originId);
    if (!cache) return;

    if (interaction.user.id !== interaction.message.interaction.user.id) {
      return interaction.reply({
        content: '❌ 𝙱ạ𝚗 𝙺𝚑ô𝚗𝚐 𝙿𝚑ả𝚒 𝙽𝚐ườ𝚒 𝙳ù𝚗𝚐 𝙻ệ𝚗𝚑 𝙽à𝚢!',
        flags: MessageFlags.Ephemeral
      });
    }

    const size = Number(interaction.values[0]);
    const user = await interaction.client.users.fetch(cache.userId);

    await interaction.deferUpdate();

    const payload = buildPayload(user, size);

    interaction.client.avatarCache.set(originId, {
      userId: cache.userId,
      size
    });

    await interaction.editReply({
      flags: MessageFlags.IsComponentsV2,
      components: [payload.container, ...payload.rows]
    });
  }
};