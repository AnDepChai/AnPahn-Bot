const {
  SlashCommandBuilder,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder
} = require('discord.js');

const PER_PAGE = 6;

function buildContainer(commands, page, totalPages) {
  const listText = commands.length
    ? commands
        .map(
          cmd =>
            `**/${cmd.data.name}**\n${cmd.data.description}`
        )
        .join('\n\n')
    : '❌ ᴋʜôɴɢ ᴄᴏ́ ʟᴇ̣̂ɴʜ.';

  return new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# 📖 ᴅᴀɴʜ sᴀ́ᴄʜ ʟᴇ̣̂ɴʜ`
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(listText)
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `Trang ${page + 1} / ${totalPages}\n© ᴄᴏᴅᴇ ʙʏ ᴀɴ ᴘᴀʜɴ 🐧`
      )
    );
}

function buildButtons(page, totalPages) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('help:first')
      .setEmoji('⏮')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(page === 0),

    new ButtonBuilder()
      .setCustomId('help:prev')
      .setEmoji('◀')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(page === 0),

    new ButtonBuilder()
      .setCustomId('help:next')
      .setEmoji('▶')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(page >= totalPages - 1),

    new ButtonBuilder()
      .setCustomId('help:last')
      .setEmoji('⏭')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(page >= totalPages - 1)
  );
}

function buildSearchDropdown(commands) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('help:search')
      .setPlaceholder('🔍 Tìm lệnh...')
      .addOptions(
        commands.slice(0, 25).map(cmd => ({
          label: `/${cmd.data.name}`,
          description: cmd.data.description.slice(0, 100),
          value: cmd.data.name
        }))
      )
  );
}

function buildResetButton() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('help:reset')
      .setLabel('↩ ǫᴜᴀʏ ʟạɪ')
      .setStyle(ButtonStyle.Success)
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('ʜɪệɴ ᴛấᴛ ᴄả ᴄáᴄ ʟệɴʜ ᴄᴜ̉ᴀ ʙᴏᴛ.'),

  async execute(interaction) {
    const allCommands = [...interaction.client.commands.values()].filter(
      c => c?.data?.name
    );

    let page = 0;
    const totalPages = Math.max(
      1,
      Math.ceil(allCommands.length / PER_PAGE)
    );

    const slice = () =>
      allCommands.slice(
        page * PER_PAGE,
        page * PER_PAGE + PER_PAGE
      );

    await interaction.reply({
      flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      components: [
        buildContainer(slice(), page, totalPages),
        buildSearchDropdown(allCommands),
        buildButtons(page, totalPages)
      ],
      allowedMentions: { parse: [] }
    });

    interaction.client.helpState ??= new Map();
    interaction.client.helpState.set(interaction.id, {
      page,
      allCommands
    });
  },

  async handleButton(interaction) {
    const rootId = interaction.message.interaction?.id;
    const state = interaction.client.helpState?.get(rootId);
    if (!state) return interaction.deferUpdate();

    let { page, allCommands } = state;
    const totalPages = Math.max(
      1,
      Math.ceil(allCommands.length / PER_PAGE)
    );

    if (interaction.customId === 'help:reset') {
      const slice = allCommands.slice(
        page * PER_PAGE,
        page * PER_PAGE + PER_PAGE
      );

      return interaction.update({
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        components: [
          buildContainer(slice, page, totalPages),
          buildSearchDropdown(allCommands),
          buildButtons(page, totalPages)
        ]
      });
    }

    if (interaction.customId === 'help:first') page = 0;
    if (interaction.customId === 'help:prev') page--;
    if (interaction.customId === 'help:next') page++;
    if (interaction.customId === 'help:last') page = totalPages - 1;

    page = Math.max(0, Math.min(page, totalPages - 1));
    state.page = page;

    const slice = allCommands.slice(
      page * PER_PAGE,
      page * PER_PAGE + PER_PAGE
    );

    await interaction.update({
      flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      components: [
        buildContainer(slice, page, totalPages),
        buildSearchDropdown(allCommands),
        buildButtons(page, totalPages)
      ]
    });
  },

  async handleSelect(interaction) {
    if (interaction.customId !== 'help:search') return;

    const commandName = interaction.values[0];
    const command = interaction.client.commands.get(commandName);

    if (!command) {
      return interaction.update({
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        components: [
          new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              '❌ ᴋʜôɴɢ ᴄᴏ́ ʟᴇ̣̂ɴʜ.'
            )
          )
        ]
      });
    }

    const container = new ContainerBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `# 📌 /${command.data.name}`
        )
      )
      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          command.data.description
        )
      )
      .addSeparatorComponents(
        new SeparatorBuilder()
          .setDivider(true)
          .setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          '⬇ ʙấᴍ ɴúᴛ ᴅướɪ để ǫᴜᴀʏ ʟạɪ ᴅᴀɴʜ sáᴄʜ ʟệɴʜ.'
        )
      );

    await interaction.update({
      flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      components: [
        container,
        buildResetButton()
      ]
    });
  }
};