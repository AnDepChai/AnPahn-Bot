class PhishingStore {
  constructor() {
    this.domains = new Map();
  }

  add(domain) {
    this.domains.set(domain, true);
  }

  isPhishing(domain) {
    if (this.domains.has(domain)) return true;

    const parts = domain.split('.');
    for (let i = 1; i < parts.length; i++) {
      const root = parts.slice(i).join('.');
      if (this.domains.has(root)) return true;
    }

    return false;
  }
}

module.exports = PhishingStore;