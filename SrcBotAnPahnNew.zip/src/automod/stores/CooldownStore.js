class CooldownStore {
  constructor() {
    // Map<guildId, Map<userId, data>>
    this.store = new Map();
  }

  _getGuild(guildId) {
    if (!this.store.has(guildId)) {
      this.store.set(guildId, new Map());
    }
    return this.store.get(guildId);
  }

  get(guildId, userId) {
    return this._getGuild(guildId).get(userId);
  }

  set(guildId, userId, data) {
    this._getGuild(guildId).set(userId, data);
  }

  delete(guildId, userId) {
    this._getGuild(guildId).delete(userId);
  }

  resetGuild(guildId) {
    this.store.delete(guildId);
  }
}

module.exports = CooldownStore;