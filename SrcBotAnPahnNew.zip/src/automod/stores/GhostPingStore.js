class GhostPingStore {
  constructor() {
    this.map = new Map();
  }

  add(message) {
    this.map.set(message.id, {
      guildId: message.guild.id,
      userId: message.author.id,
      mentions: message.mentions.users.size,
      timestamp: Date.now()
    });
  }

  get(messageId) {
    return this.map.get(messageId);
  }

  delete(messageId) {
    this.map.delete(messageId);
  }
}

module.exports = GhostPingStore;