class WarnStore {
  constructor() {
    this.store = new Map();
  }

  _key(guildId, userId) {
    return `${guildId}:${userId}`;
  }

  add(guildId, userId, reason) {
    const key = this._key(guildId, userId);
    const data = this.store.get(key) || { count: 0, reasons: [] };

    data.count++;
    data.reasons.push({
      reason,
      at: Date.now()
    });

    if (data.reasons.length > 5) {
      data.reasons.shift();
    }

    this.store.set(key, data);
    return data.count;
  }

  get(guildId, userId) {
    return this.store.get(this._key(guildId, userId));
  }

  reset(guildId, userId) {
    this.store.delete(this._key(guildId, userId));
  }
}

module.exports = WarnStore;