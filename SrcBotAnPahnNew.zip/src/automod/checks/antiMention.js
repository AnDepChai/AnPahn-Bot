module.exports = function antiMention(message, cfg) {
  const total =
    message.mentions.users.size +
    message.mentions.roles.size;

  return total >= cfg.maxMentions;
};