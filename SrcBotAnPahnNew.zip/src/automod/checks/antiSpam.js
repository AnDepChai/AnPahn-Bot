module.exports = function antiSpam(store, guildId, userId, cfg) {
  const now = Date.now();
  const data = store.get(guildId, userId);

  if (!data) {
    store.set(guildId, userId, { count: 1, last: now });
    return false;
  }

  if (now - data.last > cfg.duration) {
    store.set(guildId, userId, { count: 1, last: now });
    return false;
  }

  data.count++;
  data.last = now;
  store.set(guildId, userId, data);

  return data.count > cfg.maxMessages;
};