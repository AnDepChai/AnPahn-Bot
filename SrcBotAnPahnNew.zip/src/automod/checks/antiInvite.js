const INVITE_REGEX =
  /(discord\.gg|discord\.com\/invite|discord\.me|discord\.io)\/\S+/i;

module.exports = function antiInvite(content) {
  return INVITE_REGEX.test(content);
};