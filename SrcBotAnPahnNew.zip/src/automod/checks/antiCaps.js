module.exports = function antiCapsV2(content, cfg) {
  if (!content) return false;
  if (content.length < cfg.minLength) return false;

  /* Remove code blocks */
  if (cfg.ignoreCodeBlock) {
    content = content.replace(/```[\s\S]*?```/g, '');
    content = content.replace(/`.*?`/g, '');
  }

  /* Split words */
  const words = content.split(/\s+/);

  let letters = 0;
  let caps = 0;

  for (let word of words) {
    if (cfg.ignoreShortWords && word.length <= 2) continue;
    if (cfg.ignoredWords?.includes(word)) continue;

    for (const ch of word) {
      if (cfg.ignoreEmoji && /\p{Extended_Pictographic}/u.test(ch)) continue;
      if (cfg.ignoreNumbers && /\d/.test(ch)) continue;

      if (/[a-zA-Z]/.test(ch)) {
        letters++;
        if (ch === ch.toUpperCase()) caps++;
      }
    }
  }

  if (letters < cfg.minLetters) return false;

  return caps / letters >= cfg.ratio;
};