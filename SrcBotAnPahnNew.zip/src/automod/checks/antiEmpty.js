const INVISIBLE_REGEX =
  /[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g;

module.exports = function antiEmpty(message) {
  if (!message.content) return false;

  const cleaned = message.content
    .replace(INVISIBLE_REGEX, '')
    .trim();

  return cleaned.length === 0;
};