module.exports = function ghostPing(data, maxTime = 5000) {
  if (!data) return false;

  const age = Date.now() - data.timestamp;

  if (data.mentions > 0 && age <= maxTime) {
    return true;
  }

  return false;
};