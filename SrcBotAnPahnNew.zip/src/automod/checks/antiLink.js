const URL_REGEX = /(https?:\/\/[^\s]+)/gi;

module.exports = async function antiLink(message, phishingStore) {
  const urls = message.content.match(URL_REGEX);
  if (!urls) return false;

  for (const url of urls) {
    let host;
    try {
      host = new URL(url).hostname.replace(/^www\./, '');
    } catch {
      return true;
    }

    if (phishingStore.isPhishing(host)) {
      return true;
    }
  }

  return false;
};