const { Events } = require('discord.js');
const config = require('../config.json');

const WarnStore = require('./stores/WarnStore');
const CooldownStore = require('./stores/CooldownStore');
const PhishingStore = require('./stores/PhishingStore');
const GhostPingStore = require('./stores/GhostPingStore');

const antiSpam = require('./checks/antiSpam');
const antiLink = require('./checks/antiLink');
const antiInvite = require('./checks/antiInvite');
const antiCaps = require('./checks/antiCaps');
const antiMention = require('./checks/antiMention');
const antiEmpty = require('./checks/antiEmpty');
const ghostPing = require('./checks/ghostPing');

const punish = require('./punishments/punish');
const { createWarnEmbed, createTimeoutEmbed } = require('./utils/warnEmbed');

class AutoModManager {
  constructor(client) {
    this.client = client;

    this.warns = new WarnStore();
    this.cooldowns = new CooldownStore();
    this.phishing = new PhishingStore();
    this.ghostPings = new GhostPingStore();

    this.ownerIDs = Array.isArray(config.OwnerIDs)
      ? config.OwnerIDs
      : [];

    this._init();
  }

  _init() {
    this.client.on(Events.MessageCreate, (m) =>
      this._onMessage(m)
    );

    this.client.on(Events.MessageDelete, (m) =>
      this._onMessageDelete(m)
    );
  }

  async _onMessage(message) {
    if (!message.guild) return;
    if (!message.author || message.author.bot) return;
    if (message.webhookId) return;

    // OWNER BYPASS ONLY
    if (this.ownerIDs.includes(message.author.id)) return;

    const cfg = config.automod;
    if (!cfg?.enabled) return;

    const { guild, author, member, channel } = message;
    if (!member) return;

    if (message.mentions.users.size > 0) {
      this.ghostPings.add(message);
    }

    /* Anti Empty / Invisible */
    if (antiEmpty(message)) {
      await message.delete().catch(() => {});
      const count = this.warns.add(
        guild.id,
        author.id,
        'Tin nhắn rỗng / Invisible'
      );
      return this._handleWarn(
        message,
        count,
        'Tin nhắn rỗng / Invisible'
      );
    }

    /* Anti-Spam */
    if (cfg.cooldown?.enabled) {
      if (
        antiSpam(this.cooldowns, guild.id, author.id, cfg.cooldown)
      ) {
        await message.delete().catch(() => {});
        const count = this.warns.add(
          guild.id,
          author.id,
          'Spam tin nhắn'
        );
        return this._handleWarn(message, count, 'Spam tin nhắn');
      }
    }

    /* Anti-Link */
    if (cfg.antiLink?.enabled) {
      if (await antiLink(message, this.phishing)) {
        await message.delete().catch(() => {});
        const count = this.warns.add(
          guild.id,
          author.id,
          'Link độc hại / lừa đảo'
        );
        return this._handleWarn(
          message,
          count,
          'Link độc hại / lừa đảo'
        );
      }
    }

    /* Anti-Invite */
    if (cfg.antiInvite?.enabled) {
      if (antiInvite(message.content)) {
        await message.delete().catch(() => {});
        const count = this.warns.add(
          guild.id,
          author.id,
          'Gửi link invite Discord'
        );
        return this._handleWarn(
          message,
          count,
          'Gửi link invite Discord'
        );
      }
    }

    /* Anti-Caps */
    if (cfg.antiCaps?.enabled) {
      if (antiCaps(message.content, cfg.antiCaps)) {
        await message.delete().catch(() => {});
        const count = this.warns.add(
          guild.id,
          author.id,
          'Lạm dụng chữ in hoa'
        );
        return this._handleWarn(
          message,
          count,
          'Lạm dụng chữ in hoa'
        );
      }
    }

    /* Anti-Mention */
    if (cfg.antiMention?.enabled) {
      if (antiMention(message, cfg.antiMention)) {
        await message.delete().catch(() => {});
        const count = this.warns.add(
          guild.id,
          author.id,
          'Mention quá nhiều người'
        );
        return this._handleWarn(
          message,
          count,
          'Mention quá nhiều người'
        );
      }
    }
  }

  async _onMessageDelete(message) {
    if (!message.guild || !message.author) return;

    const data = this.ghostPings.get(message.id);
    if (!data) return;

    if (ghostPing(data)) {
      const member = await message.guild.members
        .fetch(data.userId)
        .catch(() => null);

      if (member) {
        const count = this.warns.add(
          data.guildId,
          data.userId,
          'Ghost ping'
        );

        await this._handleWarn(
          {
            guild: message.guild,
            author: member.user,
            member,
            channel: message.channel
          },
          count,
          'Ghost ping'
        );
      }
    }

    this.ghostPings.delete(message.id);
  }

  async _handleWarn(message, count, reason) {
    const { guild, author, member, channel } = message;
    const cfg = config.automod.warnings;

    const warnMsg = await channel.send({
      embeds: [
        createWarnEmbed({
          user: author,
          reason,
          count,
          max: cfg.maxWarnings
        })
      ]
    });

    setTimeout(() => warnMsg.delete().catch(() => {}), 5000);

    if (count >= cfg.maxWarnings) {
      if (member?.moderatable) {
        await punish(member, cfg);
      }

      this.warns.reset(guild.id, author.id);

      const tMsg = await channel.send({
        embeds: [
          createTimeoutEmbed({
            user: author,
            duration: cfg.timeoutDuration
          })
        ]
      });

      setTimeout(() => tMsg.delete().catch(() => {}), 7000);
    }
  }
}

module.exports = AutoModManager;