const { EmbedBuilder } = require('discord.js');

function createWarnEmbed({ user, reason, count, max }) {
  return new EmbedBuilder()
    .setColor(0xffa500)
    .setTitle('⚠️ AutoMod Cảnh Báo')
    .setDescription(
      `**Người dùng:** ${user}\n` +
      `**Lý do:** ${reason}\n` +
      `**Cảnh báo:** ${count}/${max}`
    )
    .setTimestamp();
}

function createTimeoutEmbed({ user, duration }) {
  return new EmbedBuilder()
    .setColor(0xff0000)
    .setTitle('⏰ AutoMod Timeout')
    .setDescription(
      `**Người dùng:** ${user}\n` +
      `**Thời gian:** ${duration / 60000} phút`
    )
    .setTimestamp();
}

module.exports = {
  createWarnEmbed,
  createTimeoutEmbed
};