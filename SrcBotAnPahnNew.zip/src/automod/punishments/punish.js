module.exports = async function punish(member, cfg) {
  if (!member || !member.moderatable) return;
  await member.timeout(cfg.timeoutDuration, 'AutoMod: đạt giới hạn cảnh báo');
};